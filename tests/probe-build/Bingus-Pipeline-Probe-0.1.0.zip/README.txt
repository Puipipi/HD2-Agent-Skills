Bingus Pipeline Probe - quick guide

This is a probe mod, not a gameplay mod. It exists to prove that a mod built by
the hd2-bingus-mod-development pipeline loads and runs.

What it does:
  - writes Logs/BingusPipelineProbe.log when it loads
  - writes Logs/BingusPipelineProbe-STATUS.txt on load and every 600 frames
  - logs "PIPELINE OK: all stages reached" once the engine is ready

How to confirm it worked:
  1. open %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\BingusPipelineProbe.log
  2. look for "enter version=" (it loaded) and "PIPELINE OK" (it ran)
  3. if you only see "stage N (...) held: <reason>", that line names the
     precondition that was not true yet - that is the whole point of the log

It changes no game data and patches nothing. Delete the mod folder to remove it.
